import neurotorch.gui.window as window
import neurotorch.gui.settings as settings

settings.UserSettings.ReadSettings()
window.GUI.GUI(window.Edition.NEUROTORCH_LIGHT)