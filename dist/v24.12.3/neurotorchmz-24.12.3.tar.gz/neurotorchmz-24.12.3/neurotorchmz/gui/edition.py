from enum import Enum


class Edition(Enum):
    NEUROTORCH = 1
    NEUROTORCH_LIGHT = 2
    NEUROTORCH_DEBUG = 10