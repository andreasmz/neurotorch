from . import Start
if __name__ == "__main__":
    Start()