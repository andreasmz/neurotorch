import neurotorchmz.gui.window as window
import neurotorchmz.gui.settings as settings

settings.UserSettings.ReadSettings()
window.GUI.GUI(window.Edition.NEUROTORCH)