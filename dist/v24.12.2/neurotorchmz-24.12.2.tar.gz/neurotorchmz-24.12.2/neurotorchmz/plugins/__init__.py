from .trace_selector import TraceSelector

def load_plugins(gui):
    TraceSelector(gui)